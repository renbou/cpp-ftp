#include <ghc/filesystem.hpp>

int main() {
    return 0;
}
